
package DTO;


public class AnotacoesDTO {
    
    public String anotacoes;

    public AnotacoesDTO(String anotacoes) {
        this.anotacoes = anotacoes;
    }

    public String getAnotacoes() {
        return anotacoes;
    }

    public void setAnotacoes(String anotacoes) {
        this.anotacoes = anotacoes;
    }
    
    
}
