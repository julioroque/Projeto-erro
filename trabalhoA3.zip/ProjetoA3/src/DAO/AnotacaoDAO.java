
package DAO;


public class AnotacaoDAO {
    
}
